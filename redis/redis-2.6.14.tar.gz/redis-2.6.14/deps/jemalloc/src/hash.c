#define	JEMALLOC_HASH_C_
#include "jemalloc/internal/jemalloc_internal.h"
