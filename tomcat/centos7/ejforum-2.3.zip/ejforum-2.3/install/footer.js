document.write('<br/><br/><div id="footer"><p>');
document.write("��Ȩ���� &copy; 2005 - 2009 &nbsp;<a href=\"http://www.easyjforum.cn\" target=_blank>");
document.write("EasyJForum Team</a> by Hongshee software");
document.write('</p></div>');